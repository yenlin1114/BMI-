part of bmi;

double calculateBMI(double weight, double height) {
  return weight / (height * height);
}
