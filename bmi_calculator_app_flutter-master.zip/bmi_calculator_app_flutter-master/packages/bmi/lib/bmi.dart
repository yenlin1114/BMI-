library bmi;

import 'package:intl/intl.dart';

part 'bmi_calculator.dart';
part 'bmi_formatter.dart';
