# Simple BMI Calculator Flutter App

This is a starter project for my tutorial:

- [How to Create Dart Packages for Your Flutter Apps](https://codewithandrea.com/videos/2020-06-01-how-to-create-dart-packages-flutter-apps/)

View the [commits page](https://github.com/bizz84/bmi_calculator_app_flutter/commits/master) to get the initial and finished code.

### [LICENSE: MIT](LICENSE.md)